import { lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { InicioSesion } from "../../vistas/publicas/InicioSesion";
import { Registro } from "../../vistas/publicas/Registro";
import { NoEncontrado } from "../../vistas/compartidas/NoEncontrado";
import { TableroPrincipal } from "../../contenedores/TableroPrincipal";



const LazyInicioSesion = lazy(()=>import("../../vistas/publicas/InicioSesion").then(()=>({default: InicioSesion})));
const LazyRegistro = lazy(()=>import("../../vistas/publicas/Registro").then(()=>({default: Registro})));
const LazyNoEncontrado = lazy(()=>import("../../vistas/compartidas/NoEncontrado").then(()=>({default: NoEncontrado})));
const LazyTableroPrincipal = lazy(()=>import("../../contenedores/TableroPrincipal").then(()=>({default: TableroPrincipal})));


export const RuteoCompleto = () => {
  return (<Routes>
    <Route path="/" element={<LazyInicioSesion/>}/>
    <Route path="/register" element={<LazyRegistro/>}/>
    <Route path="/home/*" element={<LazyTableroPrincipal/>}/>
    <Route path="*" element={<LazyNoEncontrado/>}/>
  </Routes>);
};
