export const Bienvenida=()=>{
    return(
        <div>
            <p>Hoooooooooooo! Bienvenidooooooo !!!!!!</p>
        </div>
    );
}