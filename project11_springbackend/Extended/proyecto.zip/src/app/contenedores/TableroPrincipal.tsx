import { MenuLateral } from "./MenuLateral";
import { MenuSuperior } from "./MenuSuperior";

export const TableroPrincipal=()=>{
    return(
        <div>
            <MenuSuperior/>
            <MenuLateral/>
            Acaaaaaaaa debe ir el ruteo de la parte privada
        </div>
    );
};