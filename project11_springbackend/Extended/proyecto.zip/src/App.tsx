import { Suspense } from "react";
import { BrowserRouter } from "react-router-dom";
import "./App.css";
import { RuteoCompleto } from "./app/utilidades/rutas/RuteoCompleto";

const cargando = <div>Por favor sea paciente</div>;

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={cargando}>
        <RuteoCompleto />
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
